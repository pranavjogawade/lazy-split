import { Component } from '@angular/core';

@Component({
  selector: 'reports',
  template: `
    <div>
      <h2>Reports asd a dasd </h2>
    </div>
  `
})
export class ReportsComponent {}
