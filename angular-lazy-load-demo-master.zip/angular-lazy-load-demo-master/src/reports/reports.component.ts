import { Component } from '@angular/core';

@Component({
  selector: 'reports',
  template: `
    <div>
      <h2>Reports</h2>
    </div>
  `
})
export class ReportsComponent {}
